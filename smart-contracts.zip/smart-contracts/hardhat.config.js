// https://eth-sepolia.g.alchemy.com/v2/9dB_AatAfjeOjKtK_w24kcjpVP5vpq4A

require('@nomiclabs/hardhat-waffle');

module.exports = {
  solidity : '0.8.13',
  network :{
    sepolia:{
      // sepolia testnet id
      // chainId: 11155111,
      // get the network https enpoint on alchemy
      url:'https://eth-sepolia.g.alchemy.com/v2/9dB_AatAfjeOjKtK_w24kcjpVP5vpq4A',
      // get your account secret key from metamask
      accounts:['a330589587222c5ae388b547420ee2101d3e67a223f3499a73ce52bbddc4e5d2']
    }
  }
};